#pragma once

#include "LVGL_Driver.h"
#include "SD_Card.h"
#include "Wireless.h"

#define EXAMPLE1_LVGL_TICK_PERIOD_MS  1000


void Lvgl_Example1(void);